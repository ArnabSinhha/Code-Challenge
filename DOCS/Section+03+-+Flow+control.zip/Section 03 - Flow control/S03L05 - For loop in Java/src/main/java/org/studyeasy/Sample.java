package org.studyeasy;

public class Sample {
    public static void main(String[] args) {

        for (int i = 10; i > 1; i = i - 2){

            System.out.println(i);
        }

    }
}