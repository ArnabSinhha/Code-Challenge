package org.studyeasy;

public class Main {

    public static void main(String[] args) {

        int x = 0b10011101;

        System.out.println(x);


    }
}